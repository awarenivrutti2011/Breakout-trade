# Breakout Trade DevOps Project

React + Spring Boot app with Kubernetes, Helm, Jenkins, ArgoCD, Git, and Maven.