# Breakout Trade Tech Website 🚀

This is the official landing page for **Breakout Trade Tech**, inspired by the Breakout Trade app.

## 🌐 Live Demo
Once deployed with GitHub Pages, your site will be live at:
```
https://YOUR_USERNAME.github.io/breakout-trade-tech/
```

## 📂 Project Structure
```
.
├── index.html      # Main website file
├── Dockerfile      # Docker build instructions
├── .dockerignore   # Files ignored by Docker
└── README.md       # Project documentation
```

## 🐳 Run with Docker
You can run this project inside a Docker container.

### Build Docker Image
```bash
docker build -t breakout-trade-tech .
```

### Run Container
```bash
docker run -d -p 8080:80 breakout-trade-tech
```

Now visit `http://localhost:8080` in your browser.
